<?php

$elm_Settings_ConnectionString = "";
$elm_Settings_DbUser = "";
$elm_Settings_DbPassword = "";

?>