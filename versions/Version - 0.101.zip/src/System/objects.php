<?php

class elm_User {
    public $id;
    public $name;
    public $mail;
    public $password;
    public $roleId;
}

?>