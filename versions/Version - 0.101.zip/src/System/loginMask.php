<?php
/**
 * Created by PhpStorm.
 * User: Laura
 * Date: 05.12.2017
 * Time: 18:30
 */
?>

<form action="system/login.php" method="post">
    Username: <input type="text" name="username" /><br />
			Passwort: <input type="password" name="password" /><br />
		<input type="submit" value="Anmelden" />
</form>