<?php
/**
 * This is the Mask for editing a page. If "save" is used the formular is saved in pageManagement.
 * */
?>
<h1>Seite bearbeiten</h1>
</br></br>

<form action="index.php?page=elm_Page_Edit" method="post">
    <h1></h1>
    <table>
        <td>Seitennamen: </td>
        <td><input type="text" id="elm_addPage_Titel" name="elm_addPage_Titel" size="42" autofocus ></td>
        </tr>

        <tr>
            <td>Parent Page:</td>
            <td><input type="text" id="elm_addPage_ParentPage" name="elm_addPage_ParentPage" size="42" > </td>
        </tr>

        <tr>
            <td>Keyword:</td>
            <td><input type="text" id="elm_addPage_Keyword" name="elm_addPage_Keyword" size="42" > </td>
        </tr>

        <tr>
            <td>Sortierung:</td>
            <td><input type="text" id="elm_addPage_Sorting" name="elm_addPage_Sorting" size="42" > </td>
        </tr>


        <tr>
            <td>Seiteninhalt:</td>
            <td><textarea id="elm_addPage_Content" name="elm_addPage_Content" rows="10" cols="40"></textarea> </td>
        </tr>

        <tr>
            <td colspan="2">
                <input type="submit" value="Speichern" id="elm_addPage_Execute" name="elm_addPage_Execute_admin">
            </td>
        </tr>
    </table>
</form>
