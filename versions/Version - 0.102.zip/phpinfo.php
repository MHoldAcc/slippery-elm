<?php
/**
 * Created by PhpStorm.
 * User: Drake
 * Date: 06.01.2018
 * Time: 15:40
 */
phpinfo();